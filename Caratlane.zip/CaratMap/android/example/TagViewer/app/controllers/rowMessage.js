var args = arguments[0] || {};

$.action.text = args.action.replace('android.nfc.action.', '');
