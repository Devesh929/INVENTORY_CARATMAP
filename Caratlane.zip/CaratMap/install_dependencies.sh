# Some required dependencies for LL-Fuzzer
yes | sudo apt-get -y install ia32-libs openjdk-7-jre python-pim android-tools-adb
sudo pip install pyusb

