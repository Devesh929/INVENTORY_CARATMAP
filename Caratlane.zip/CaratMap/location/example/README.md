# location_example

Demonstrates how to use the location plugin.
