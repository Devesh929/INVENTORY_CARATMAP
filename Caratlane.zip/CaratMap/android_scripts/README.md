These are scripts that must be loaded on the android phones to facilitate our 
LL Fuzzer library. 

Running ./push_scripts.sh should do this for you.

Here are some references for getting more functionality out of the android shell:

  [killall](http://en.androidwiki.com/wiki/Android_Shell_tips_and_tricks)
