# location_android

The Android implementation of `location`.

## Usage

This package is [endorsed][endorsed_link], which means you can simply use `location`
normally. This package will be automatically included in your app when you do.

[endorsed_link]: https://flutter.dev/docs/development/packages-and-plugins/developing-packages#endorsed-federated-plugin
