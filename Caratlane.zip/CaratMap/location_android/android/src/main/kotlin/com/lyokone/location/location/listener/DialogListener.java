package com.lyokone.location.location.listener;

public interface DialogListener {

    void onPositiveButtonClick();

    void onNegativeButtonClick();

}
