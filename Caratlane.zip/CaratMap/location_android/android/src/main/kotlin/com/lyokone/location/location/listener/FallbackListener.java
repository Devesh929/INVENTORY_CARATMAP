package com.lyokone.location.location.listener;

public interface FallbackListener {
    void onFallback();
}